import json
import boto3
import botocore



def lambda_handler(event, context):
    
    return("hello world")